Note:
====

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/

B-School is a Educational Responsive web design template with a modern style theme from webthemez. This template can be used for multipurpose, Educational Institutes, Collage's, Schools, Training Institutes and many more. This theme is easy to customize as per you requirements and this is developed on latest technologies like HTML5, Bootstrap 3.3.1. This is fully Responsive web site.  
 

Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed) and used form (google.com)
http://www.track2realty.com/


Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)


Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	