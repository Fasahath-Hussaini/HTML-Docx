Note
====
Free-Portfolio-HTML5-Responsive-Website-Sam

Sam Doe is a clean, modern and responsive professional looking resume / personal portfolio template for all designer and developer. well crafted Designed for user experience on mulit devices like desktop, laptop, smartphones. This template is built on Bootstrap framework which give flexibilty to customeise the theme easly as per the your requirements. Included with all latest technology HTML5 CSS3, jQuery and bootstrap.


Key features
Twitter Bootstrap 3.2.0
Valid HTML5 & CSS3
FontAwesome Icons
Gallery
Fully Responsive
Browser Compatability
Contact Form

Responsive, Bootstrap Mobile First Web Template
 
Author URI: http://webthemez.com/

License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).


Credits
=======
Framework  http://getbootstrap.com
Images	Unsplash (http://unsplash.com - CC0 licensed) 
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

